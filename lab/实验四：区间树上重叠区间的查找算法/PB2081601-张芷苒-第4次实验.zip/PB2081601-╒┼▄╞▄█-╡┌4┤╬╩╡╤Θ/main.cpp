#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

//定义红黑树的颜色：红或黑
enum NodeColour {
    RED,
    BLACK
};

//定义区间结构体，有低位和高位
struct IntervalSpan {
    int lowPoint;
    int highPoint;
};

//定义红黑树的节点结构
struct TreeNode {
    NodeColour nodeColour;
    IntervalSpan span;
    int keyValue;
    int maxValue;
    TreeNode *leftChild, *rightChild, *parent;
};

//定义红黑树结构
struct TreeStructure {
    TreeNode *treeRoot, *NILNode;
};

void InitializeTree(TreeStructure &tree) {
    tree.NILNode = new TreeNode;
    tree.NILNode->nodeColour = BLACK;
    tree.NILNode->maxValue = INT_MIN;
    tree.treeRoot = tree.NILNode;
    tree.treeRoot->parent = tree.NILNode;
}

void RotateLeft(TreeStructure &tree, TreeNode *nodeX) {
    TreeNode *nodeY;
    nodeY = nodeX->rightChild;
    nodeX->rightChild = nodeY->leftChild;

    if (nodeY->leftChild != tree.NILNode) {
        nodeY->leftChild->parent = nodeX;
    }

    nodeY->parent = nodeX->parent;

    if (nodeX->parent == tree.NILNode) {
        tree.treeRoot = nodeY;
    } else if (nodeX == nodeX->parent->leftChild) {
        nodeX->parent->leftChild = nodeY;
    } else {
        nodeX->parent->rightChild = nodeY;
    }

    nodeY->leftChild = nodeX;
    nodeX->parent = nodeY;
    nodeX->maxValue = max(max(nodeX->leftChild->maxValue, nodeX->rightChild->maxValue), nodeX->span.highPoint);
    nodeY->maxValue = max(max(nodeY->leftChild->maxValue, nodeY->rightChild->maxValue), nodeY->span.highPoint);
}

// 此函数实现右旋
void RotateRight(TreeStructure &tree, TreeNode *nodeX) {
    TreeNode *nodeY = nodeX->leftChild;
    nodeX->leftChild = nodeY->rightChild;

    if (nodeY->rightChild != tree.NILNode) {
        nodeY->rightChild->parent = nodeX;
    }

    nodeY->parent = nodeX->parent;

    if (nodeX->parent == tree.NILNode) {
        tree.treeRoot = nodeY;
    } else if (nodeX == nodeX->parent->leftChild) {
        nodeX->parent->leftChild = nodeY;
    } else {
        nodeX->parent->rightChild = nodeY;
    }

    nodeY->rightChild = nodeX;
    nodeX->parent = nodeY;
    nodeX->maxValue = max(max(nodeX->leftChild->maxValue, nodeX->rightChild->maxValue), nodeX->span.highPoint);
    nodeY->maxValue = max(max(nodeY->leftChild->maxValue, nodeY->rightChild->maxValue), nodeY->span.highPoint);
}

void AdjustMaxValue(TreeStructure &tree, TreeNode *z) {
    TreeNode *currentNode = z;
    while (currentNode != tree.NILNode) {
        currentNode->maxValue = max(max(currentNode->leftChild->maxValue, currentNode->rightChild->maxValue), currentNode->span.highPoint);
        currentNode = currentNode->parent;
    }
}

void InsertFix(TreeStructure &tree, TreeNode *z) {
    TreeNode *tempNode;
    while (z->parent->nodeColour == RED) {
        if (z->parent == z->parent->parent->leftChild) {
            tempNode = z->parent->parent->rightChild;

            if (tempNode->nodeColour == RED) {
                z->parent->nodeColour = BLACK;
                tempNode->nodeColour = BLACK;
                z->parent->parent->nodeColour = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->rightChild) {
                    z = z->parent;
                    RotateLeft(tree, z);
                }
                z->parent->nodeColour = BLACK;
                z->parent->parent->nodeColour = RED;
                RotateRight(tree, z->parent->parent);
            }
        } else {
            tempNode = z->parent->parent->leftChild;

            if (tempNode->nodeColour == RED) {
                z->parent->nodeColour = BLACK;
                tempNode->nodeColour = BLACK;
                z->parent->parent->nodeColour = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->leftChild) {
                    z = z->parent;
                    RotateRight(tree, z);
                }
                z->parent->nodeColour = BLACK;
                z->parent->parent->nodeColour = RED;
                RotateLeft(tree, z->parent->parent);
            }
        }
    }
    tree.treeRoot->nodeColour = BLACK;
}

void InsertNode(TreeStructure &tree, TreeNode *z) {
    TreeNode *temp1 = tree.NILNode;
    TreeNode *temp2 = tree.treeRoot;

    while (temp2 != tree.NILNode) {
        temp1 = temp2;
        if (z->keyValue < temp2->keyValue) {
            temp2 = temp2->leftChild;
        } else {
            temp2 = temp2->rightChild;
        }
    }

    z->parent = temp1;

    if (temp1 == tree.NILNode) {
        tree.treeRoot = z;
    } else if (z->keyValue < temp1->keyValue) {
        temp1->leftChild = z;
    } else {
        temp1->rightChild = z;
    }

    z->leftChild = tree.NILNode;
    z->rightChild = tree.NILNode;
    z->nodeColour = RED;

    AdjustMaxValue(tree, z);
    InsertFix(tree, z);
}

// 判断两个区间是否有重叠
int IsOverlap(IntervalSpan x, IntervalSpan y) {
    return !(x.highPoint < y.lowPoint || x.lowPoint > y.highPoint);
}

// 查找与查询区间重叠的区间
TreeNode *SearchOverlapInterval(TreeStructure &tree, IntervalSpan querySpan) {
    TreeNode *currentNode = tree.treeRoot;
    while (currentNode != tree.NILNode && !IsOverlap(querySpan, currentNode->span)) {
        if (currentNode->leftChild != tree.NILNode && currentNode->leftChild->maxValue >= querySpan.lowPoint) {
            currentNode = currentNode->leftChild;
        } else {
            currentNode = currentNode->rightChild;
        }
    }
    return currentNode;
}

void InOrderTraversal(TreeStructure &tree, TreeNode *node, ofstream &outputFile) {
    if (node != tree.NILNode) {
        InOrderTraversal(tree, node->leftChild, outputFile);
        outputFile << "[" << node->span.lowPoint << ", " << node->span.highPoint << "], max: " << node->maxValue << ", color: " << (node->nodeColour == RED ? "RED" : "BLACK") << "\n";
        InOrderTraversal(tree, node->rightChild, outputFile);
    }
}

int main() {
    TreeStructure tree;
    InitializeTree(tree);

    int numIntervals, low, high;
    cout << "请输入区间数目: ";
    cin >> numIntervals;

    for (int i = 0; i < numIntervals; ++i) {
        cout << "请输入第 " << i + 1 << " 个区间的低位和高位（如：2 5）: ";
        cin >> low >> high;

        TreeNode *node = new TreeNode;
        node->span.lowPoint = low;
        node->span.highPoint = high;
        node->keyValue = low;
        InsertNode(tree, node);
    }

    ofstream outputFile("output.txt");

    outputFile << "中序遍历红黑树结果：\n";
    InOrderTraversal(tree, tree.treeRoot, outputFile);

    IntervalSpan querySpan;
    cout << "请输入查询区间的低位和高位（如：2 5）: ";
    cin >> querySpan.lowPoint >> querySpan.highPoint;

    TreeNode *searchResult = SearchOverlapInterval(tree, querySpan);
    if (searchResult == tree.NILNode) {
        outputFile << "与区间 [" << querySpan.lowPoint << ", " << querySpan.highPoint << "] 无重叠的区间.\n";
    } else {
        outputFile << "与区间 [" << querySpan.lowPoint << ", " << querySpan.highPoint << "] 重叠的区间是: [" << searchResult->span.lowPoint << ", " << searchResult->span.highPoint << "].\n";
    }

    outputFile.close();

    return 0;
}
