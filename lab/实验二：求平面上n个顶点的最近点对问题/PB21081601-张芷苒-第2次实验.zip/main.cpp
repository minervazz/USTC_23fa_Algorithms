#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

// 定义点的结构体
struct Point
{
    int num;    // 点的编号
    double x, y; // 点的坐标
} point[10000], pointByX[10000], pointByY[10000];

int pos1, pos2; // 存储最近点对的位置
int n, temp[10000];

// 按x坐标比较点
bool cmpX(const Point &A, const Point &B)
{
    return A.x < B.x;
}
// 按y坐标比较点
bool cmpY(const Point &A, const Point &B)
{
    return A.y < B.y;
}

// 计算两点之间的距离
double Distance(Point a, Point b)
{
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

// 暴力方法查找最近的点对
double ViolentFind(Point t[], int length)
{
    double dis;
    double temp = Distance(t[0], t[1]);
    pos1 = 0;
    pos2 = 1;
    for (int i = 0; i < length; i++)
    {
        for (int j = i + 1; j < length; j++)
        {
            dis = Distance(t[i], t[j]);
            if (temp > dis)
            {
                temp = dis;
                pos1 = i;
                pos2 = j;
            }
        }
    }
    return temp;
}

// 使用分治算法查找最近的点对
double NearestPair(Point tempX[], Point tempY[], int length, Point &a, Point &b)
{
    // 对于少于3个点的情况，使用暴力方法查找最近的点对
    if (length <= 3)
    {
        return ViolentFind(tempX, length);
    }

    int mid = length / 2; // 计算中点
    Point leftX[mid];
    Point rightX[length - mid];
    Point leftY[mid];
    Point rightY[length - mid];

    memcpy(leftX, tempX, mid * sizeof(Point));
    memcpy(rightX, tempX + mid, (length - mid) * sizeof(Point));

    int leftCount = 0, rightCount = 0;
    for (int i = 0; i < length; i++)
    {
        if (tempY[i].x <= tempX[mid].x)
            leftY[leftCount++] = tempY[i];
        else
            rightY[rightCount++] = tempY[i];
    }

    Point a1, b1, a2, b2;
    double leftDist = NearestPair(leftX, leftY, mid, a1, b1);
    double rightDist = NearestPair(rightX, rightY, length - mid, a2, b2);

    if (leftDist < rightDist)
    {
        a = a1;
        b = b1;
        return leftDist;
    }
    else
    {
        a = a2;
        b = b2;
        return rightDist;
    }
}

int main()
{
    LARGE_INTEGER start, finish, tc;
    double TotalTime = 0;
    Point a, b;
    double dis;
    int i = 1;
    int j = -1;
    ifstream infile("data.txt", ios_base::in);
    if (!infile)
    {
        cout << "文件不存在!";
        return 0;
    }
    double tempData;
    while (infile >> tempData)
    {
        if (i % 3 == 1)
        {
            j++;
            point[j].num = tempData;
        }
        else if (i % 3 == 2)
        {
            point[j].x = tempData;
        }
        else
        {
            point[j].y = tempData;
        }
        i++;
    }

    sort(point, point + 10000, cmpX);
    memcpy(pointByX, point, sizeof(point));
    sort(point, point + 10000, cmpY);
    memcpy(pointByY, point, sizeof(point));

    QueryPerformanceFrequency(&tc);
    QueryPerformanceCounter(&start);
    
    // dis = NearestPair(pointByX, pointByY, 10000, a, b);
    dis = ViolentFind(point, 10000);
    
    QueryPerformanceCounter(&finish);

    TotalTime = (finish.QuadPart - start.QuadPart) / (double)tc.QuadPart * 1000;
    cout << a.num << " " << b.num << " " << dis;
    cout << endl << "TotalTime is " << TotalTime << " ms" << endl;

    return 0;
}
