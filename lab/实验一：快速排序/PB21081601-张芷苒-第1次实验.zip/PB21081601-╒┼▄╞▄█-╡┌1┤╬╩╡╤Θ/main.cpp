#include<chrono>
#include<iostream>
#include<fstream>
#include<cstdlib>

#define EARLY_EXIT_THRESHOLD 50 // 定义早期退出的阈值

// 插入排序函数
void insertSort(int* arr, int left, int right) {
    int tmpValue; 
    for (int idx = left + 1; idx <= right; idx++) {
        tmpValue = arr[idx];
        int j = idx - 1;
        while (j >= left && arr[j] > tmpValue) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = tmpValue;
    }
}

// 选择排序基准值
int selectSample(int* arr, int left, int right, int choice){
    int midValue;
    switch (choice) {
        case 0: // 固定基准
            return right;
        case 1: // 随机基准
            return left + rand() % (right - left + 1);
        case 2: // 三数取中法
            midValue = (left + right) / 2;
            if (arr[left] > arr[midValue]) {
                if (arr[midValue] > arr[right]) return midValue;
                else if (arr[left] > arr[right]) return right;
                else return left;
            } else {
                if (arr[left] > arr[right]) return left;
                else if (arr[midValue] > arr[right]) return right;
                else return midValue;
            }
        default:
            return right;
    }
}

// 快速排序函数
void quickSortAlgorithm(int* arr, int left, int right, int choice) {
    int i = left, j = right - 1;
    int tmpValue;
    int sampleIdx = selectSample(arr, left, right, choice);
    int pivot = arr[sampleIdx];

    if (right - left + 1 <= 1) return;
    if (right - left + 1 == 2) {
        if (arr[left] > arr[right]) {
            std::swap(arr[left], arr[right]);
        }
        return;
    }

    std::swap(arr[sampleIdx], arr[right]);

    while (i <= j) {
        while (arr[i] <= pivot) i++;
        while (arr[j] > pivot) j--;
        if (i <= j) {
            std::swap(arr[i], arr[j]);
            i++;
            j--;
        }
    };

    std::swap(arr[i], arr[right]);

    if (left < j && !(choice == 3 && right - left + 1 < EARLY_EXIT_THRESHOLD)) 
        quickSortAlgorithm(arr, left, j, choice);
    if (i < right && !(choice == 3 && right - left + 1 < EARLY_EXIT_THRESHOLD)) 
        quickSortAlgorithm(arr, i + 1, right, choice);
}

int main() {
    int dataLength;
    std::ifstream inputData("data.txt", std::ios::in);
    inputData >> dataLength;
    int* dataArray = new int[dataLength];
    for (int i = 0; i < dataLength; i++) inputData >> dataArray[i];
    inputData.close();

    int* sortedArray = new int[dataLength];

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < dataLength; j++) sortedArray[j] = dataArray[j];

        auto startTime = std::chrono::steady_clock::now();
        quickSortAlgorithm(sortedArray, 0, dataLength - 1, i);
        if (i == 3) insertSort(sortedArray, 0, dataLength - 1);
        auto endTime = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsedTime = endTime - startTime;

        const char* outputFiles[] = {"sorted_fix.txt", "sorted_random.txt", "sorted_median.txt", "sorted_exit.txt"};
        std::ofstream outputData(outputFiles[i], std::ios::out);
        for (int j = 0; j < dataLength; j++) outputData << sortedArray[j] << " ";
        outputData.close();

        const char* methodNames[] = {"fix", "random", "median of three", "early exit"};
        std::cout << methodNames[i] << ": " << elapsedTime.count() << " s" << std::endl;
    }

    // delete[] sortedArray;
    return 0;
}
