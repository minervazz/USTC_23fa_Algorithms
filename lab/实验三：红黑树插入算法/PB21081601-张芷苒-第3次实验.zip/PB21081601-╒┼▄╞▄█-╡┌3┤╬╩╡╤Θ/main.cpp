#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

// 定义红黑树的颜色
enum Colour {
    RED,
    BLACK
};

// 红黑树结点定义
struct RBNode {
    Colour color;        // 颜色
    int key;             // 关键字
    RBNode *left;        // 左孩子
    RBNode *right;       // 右孩子
    RBNode *p;           // 父节点
};

// 红黑树定义
struct RBTree {
    RBNode* root;        // 根节点
    RBNode* NIL;         // NIL哨兵节点
};

// 初始化红黑树
void RBTInit(RBTree& T) {
    T.NIL = new RBNode;
    T.NIL->color = BLACK;
    T.root = T.NIL;
    T.root->p = T.NIL;
}

// 左旋操作
void LeftRotate(RBTree& T, RBNode* x) {
    RBNode* y = x->right;
    x->right = y->left;

    if (y->left != T.NIL) {
        y->left->p = x;
    }

    y->p = x->p;

    if (x->p == T.NIL) {
        T.root = y;
    } else if (x == x->p->left) {
        x->p->left = y;
    } else {
        x->p->right = y;
    }

    y->left = x;
    x->p = y;
}

// 右旋操作
void RightRotate(RBTree& T, RBNode* x) {
    RBNode* y = x->left;
    x->left = y->right;

    if (y->right != T.NIL) {
        y->right->p = x;
    }

    y->p = x->p;

    if (x->p == T.NIL) {
        T.root = y;
    } else if (x == x->p->left) {
        x->p->left = y;
    } else {
        x->p->right = y;
    }

    y->right = x;
    x->p = y;
}

// 插入修复操作
void RBInsertFixup(RBTree& T, RBNode* z) {
    RBNode* y;
    while (z->p->color == RED) {
        if (z->p == z->p->p->left) {
            y = z->p->p->right;

            if (y->color == RED) {
                // 情况1
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else {
                if (z == z->p->right) {
                    // 情况2
                    z = z->p;
                    LeftRotate(T, z);
                }
                // 情况3
                z->p->color = BLACK;
                z->p->p->color = RED;
                RightRotate(T, z->p->p);
            }
        } else {
            y = z->p->p->left;

            if (y->color == RED) {
                // 情况4
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else {
                if (z == z->p->left) {
                    // 情况5
                    z = z->p;
                    RightRotate(T, z);
                }
                // 情况6
                z->p->color = BLACK;
                z->p->p->color = RED;
                LeftRotate(T, z->p->p);
            }
        }
    }
    T.root->color = BLACK;
}

// 插入操作
void RBInsert(RBTree& T, RBNode* z) {
    RBNode* y = T.NIL;
    RBNode* x = T.root;

    while (x != T.NIL) {
        y = x;
        if (z->key < x->key) {
            x = x->left;
        } else {
            x = x->right;
        }
    }

    z->p = y;

    if (y == T.NIL) {
        T.root = z;
    } else if (z->key < y->key) {
        y->left = z;
    } else {
        y->right = z;
    }

    z->left = T.NIL;
    z->right = T.NIL;
    z->color = RED;

    RBInsertFixup(T, z);
}

// 前序遍历
void FirstOrder(const RBTree& T, RBNode* t, ofstream& outfile) {
    if (t == T.NIL) {
        return;
    }

    outfile << t->key << " ";
    outfile << (t->color == RED ? "red" : "black") << endl;
    FirstOrder(T, t->left, outfile);
    FirstOrder(T, t->right, outfile);
}

// 中序遍历
void InOrder(const RBTree& T, RBNode* t, ofstream& outfile) {
    if (t == T.NIL) {
        return;
    }

    InOrder(T, t->left, outfile);
    outfile << t->key << " ";
    outfile << (t->color == RED ? "red" : "black") << endl;
    InOrder(T, t->right, outfile);
}

// 层次遍历
void FloorOrder(const RBTree& T, RBNode* t, ofstream& outfile) {
    if (t == T.NIL) {
        return;
    }

    queue<RBNode*> q;
    q.push(t);
    while (!q.empty()) {
        RBNode* node = q.front();
        outfile << node->key << " ";
        outfile << (node->color == RED ? "red" : "black") << endl;

        if (node->left != T.NIL) {
            q.push(node->left);
        }
        if (node->right != T.NIL) {
            q.push(node->right);
        }
        q.pop();
    }
}

int main() {
    int num;
    ifstream infile("insert.txt");

    if (!infile) {
        cout << "文件不存在!";
        return 0;
    }

    infile >> num;
    vector<int> keys(num);
    for (int i = 0; i < num; ++i) {
        infile >> keys[i];
    }

    RBTree T;
    RBTInit(T);

    for (int key : keys) {
        cout << key << "插入时经历的情况：" << endl;
        RBNode* z = new RBNode;
        z->key = key;
        z->color = RED;
        RBInsert(T, z);
        cout << endl;
    }

    ofstream outfile1("preorder.txt");
    FirstOrder(T, T.root, outfile1);
    outfile1.close();

    ofstream outfile2("inorder.txt");
    InOrder(T, T.root, outfile2);
    outfile2.close();

    ofstream outfile3("floororder.txt");
    FloorOrder(T, T.root, outfile3);
    outfile3.close();

    return 0;
}
